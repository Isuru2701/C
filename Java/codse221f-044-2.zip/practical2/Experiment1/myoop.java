class Student {
    public String name;
}

class OOP {
    public static void main(String[] args) {
        Student student_1 = new Student();
        student_1.name= "Amal";
        System.out.println(student_1.name);
    }
}