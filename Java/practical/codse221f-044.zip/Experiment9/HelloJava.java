import java.util.Scanner;

class HelloJava {
	public static void main(String[] args){
		String name;
		Scanner sc  = new Scanner(System.in);
		System.out.println("Type your name");
		name = sc.next();
		System.out.println("Your name is " + name);
	
	}
		
}