import java.util.Scanner;

class VariableJava {
	public static void main(String args []){
		Scanner sc  = new Scanner(System.in);
		int number;
		System.out.println("Type your integer");
		number = Integer.parseInt(sc.next());
		System.out.println("Your integer is " + number);
		
	}
		
}