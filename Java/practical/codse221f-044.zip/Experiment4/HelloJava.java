class HelloJava {
	
	public static void main(String[] args){

		System.out.println("Hello Java\t");
		System.out.print("NIBM");

	}
		
}