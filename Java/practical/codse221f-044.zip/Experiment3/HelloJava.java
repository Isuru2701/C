class HelloJava {
	

	public static void main(String[] args){
		System.out.println("Hello Java"); //This prints and goes to next line
		System.out.print("NIBM");

	}
		
}