class HelloJava {
	
	//Experiment 1
	public static void main(String[] args){
		System.out.print("Hello Java");

	}
		
}