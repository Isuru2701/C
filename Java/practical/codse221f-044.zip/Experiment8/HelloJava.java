class HelloJava {
	public static void main(String args []){
		final int a = 50;
		//a = 30; //doesn't work,as this is a constant
		System.out.println("Value of a is " + a); 

	}
		
}