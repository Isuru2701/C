class HelloJava {
	
	public static void main(String[] args){

		System.out.print("Hello Java\n");
		System.out.print("NIBM");

	}
		
}