class HelloJava {
	
	public static void main(String[] args){
		int a = 50;
		System.out.print("Value of a is " + a);
	}
		
}