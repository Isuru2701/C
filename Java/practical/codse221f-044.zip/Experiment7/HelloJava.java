class HelloJava {
	public static void main(String args []){
		int a = 50;
		float b = 2.55f;
		char c = 'A';
		String d = "nibm";
		System.out.println("Value of a is"  + a);
		System.out.println("Value of b is"  + b);
		System.out.println("Value of c is"  + c);
		System.out.println("Value of d is"  + d);		
	}
		
}